package com.safi_d.sistemas.safiapp.Auxiliar;

/**
 * Created by usuario on 16/10/2017.
 */

public interface OnSpinerItemClick
{
    public void onClick(String item,int position);
}