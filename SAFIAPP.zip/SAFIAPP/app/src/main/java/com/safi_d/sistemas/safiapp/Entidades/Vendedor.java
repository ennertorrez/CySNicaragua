package com.safi_d.sistemas.safiapp.Entidades;

/**
 * Created by Sistemas on 6/5/2017.
 */

public class Vendedor {

    String CODIGO;
    String NOMBRE;
    String Super;
    String IDRUTA;
    String RUTA;
    String EMPRESA;
    String codsuper;
    String Supervisor;
    String Status;
    String detalle;
    String horeca;
    String mayorista;

    public Vendedor(String CODIGO, String NOMBRE, String Super, String IDRUTA, String RUTA, String EMPRESA, String codsuper, String Supervisor, String status, String detalle, String horeca, String mayorista) {
        this.CODIGO = CODIGO;
        this.NOMBRE = NOMBRE;
        this.Super = Super;
        this.IDRUTA = IDRUTA;
        this.RUTA = RUTA;
        this.EMPRESA=EMPRESA;
        this.codsuper = codsuper;
        this.Supervisor = Supervisor;
        Status = status;
        this.detalle = detalle;
        this.horeca = horeca;
        this.mayorista = mayorista;
    }

    public Vendedor() {

    }

    public String getCODIGO() {
        return  CODIGO;
    }

    public void setCODIGO(String CODIGO) {
        this.CODIGO = CODIGO;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
        this.NOMBRE = NOMBRE;
    }

    public String getSuper() {
        return Super;
    }

    public void setSuper(String Super) {
        this.Super = Super;
    }

    public String getIDRUTA() {
        return IDRUTA;
    }

    public void setIDRUTA(String IDRUTA) {
        this.IDRUTA = IDRUTA;
    }

    public String getEMPRESA() {
        return EMPRESA;
    }

    public void setEMPRESA(String EMPRESA) {
        this.EMPRESA = EMPRESA;
    }

    public String getRUTA() {
        return RUTA;
    }

    public void setRUTA(String RUTA) {
        this.RUTA = RUTA;
    }

    public String getCodsuper() {
        return codsuper;
    }

    public void setCodsuper(String codsuper) {
        this.codsuper = codsuper;
    }

    public  String getSupervisor(){return Supervisor ;}

    public  void setSupervisor(String Supervisor){this.Supervisor = Supervisor;}

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getHoreca() {
        return horeca;
    }

    public void setHoreca(String horeca) {
        this.horeca = horeca;
    }

    public String getMayorista() {
        return mayorista;
    }

    public void setMayorista(String mayorista) {
        this.mayorista = mayorista;
    }

    public String toString(){
        return this.getNOMBRE();
    }
}
