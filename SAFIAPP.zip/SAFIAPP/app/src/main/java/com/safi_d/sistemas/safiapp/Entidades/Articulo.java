package com.safi_d.sistemas.safiapp.Entidades;

/**
 * Created by Sistemas on 11/5/2017.
 */

public class Articulo {

    String Codigo= "";
    String Nombre = "";
    String Costo = "";
    String Unidad = "";
    String UnidadCaja = "";
    String Precio = "";
    String PorIva = "";
    String DescuentoMaximo = "";
    String Existencia="";
    String UnidadCajaVenta="";
    String IdProveedor="";

    public Articulo() {
    }

    public Articulo(String codigo, String nombre, String costo, String unidad, String unidadCaja, String precio, String porIva,
                    String descuentoMaximo, String existencia, String unidadCajaVenta,String idProveedor) {
        Codigo = codigo;
        Nombre = nombre;
        Costo = costo;
        Unidad = unidad;
        UnidadCaja = unidadCaja;
        Precio = precio;
        PorIva = porIva;
        DescuentoMaximo = descuentoMaximo;
        Existencia=existencia;
        UnidadCajaVenta=unidadCajaVenta;
        IdProveedor=idProveedor;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        Codigo = codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getCosto() {
        return Costo;
    }

    public void setCosto(String costo) {
        Costo = costo;
    }

    public String getUnidad() {
        return Unidad;
    }

    public void setUnidad(String unidad) {
        Unidad = unidad;
    }

    public String getUnidadCaja() {
        return UnidadCaja;
    }

    public String getExistencia() {
        return Existencia;
    }

    public void setExistencia(String existencia) {
        Existencia = existencia;
    }

    public void setUnidadCaja(String unidadCaja) {
        UnidadCaja = unidadCaja;
    }

    public String getUnidadCajaVenta() {
        return UnidadCajaVenta;
    }

    public void setUnidadCajaVenta(String unidadCajaVenta) {
        UnidadCajaVenta = unidadCajaVenta;
    }

    public String getIdProveedor() {
        return IdProveedor;
    }

    public void setIdProveedor(String idProveedor) {
        IdProveedor = idProveedor;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setIsc(String precio) {
        Precio = precio;
    }

    public String getPorIva() {
        return PorIva;
    }

    public void setPorIva(String porIva) {
        PorIva = porIva;
    }

    public String getDescuentoMaximo() {
        return DescuentoMaximo;
    }

    public void setDescuentoMaximo(String descuentoMaximo) {
        DescuentoMaximo = descuentoMaximo;
    }

    public String toString() {
        return this.getNombre();
    }

}